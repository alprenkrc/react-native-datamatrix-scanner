import cv2
import numpy as np
import zxingcpp
import sys
import os
import re

def parse_gs1(text):
    """
    Parses GS1 DataMatrix formatted string into human-readable fields.
    Handles both formatted text with (AI) and raw FNC1-separated GS1 strings.
    """
    parsed = {}
    
    # Common GS1 Application Identifiers
    # AI 01: GTIN (14 digits)
    # AI 21: Serial Number (variable length up to 20 alphanum)
    # AI 17: Expiry Date (6 digits YYMMDD)
    # AI 10: Batch/Lot (variable length up to 20 alphanum)
    
    # If already formatted with parentheses (01)...
    ai_matches = re.findall(r'\((\d+)\)([^\(]+)', text)
    if ai_matches:
        for ai, val in ai_matches:
            val = val.strip()
            if ai == '01':
                parsed['GTIN (01)'] = val
            elif ai == '21':
                parsed['Serial Number (21)'] = val
            elif ai == '17':
                if len(val) == 6:
                    year, month, day = '20' + val[0:2], val[2:4], val[4:6]
                    parsed['Expiration Date (17)'] = f"{val} ({day}.{month}.{year})"
                else:
                    parsed['Expiration Date (17)'] = val
            elif ai == '10':
                parsed['Batch / Lot (10)'] = val
            else:
                parsed[f'AI ({ai})'] = val
    return parsed

def decode_datamatrix(image_path):
    """
    Decodes DataMatrix barcode from an image file using adaptive preprocessing pipeline.
    Supports dot-matrix, distorted, low-res, tilted, and low-contrast images.
    """
    if not os.path.exists(image_path):
        return {'success': False, 'error': f"Dosya bulunamadı: {image_path}"}
        
    img = cv2.imread(image_path)
    if img is None:
        return {'success': False, 'error': f"Görüntü okunamadı: {image_path}"}
        
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape[:2]
    
    # 1. Direct read attempt
    barcodes = zxingcpp.read_barcodes(gray, formats=zxingcpp.BarcodeFormat.DataMatrix, try_rotate=True, try_downscale=True, try_invert=True)
    if barcodes:
        for b in barcodes:
            if b.text or b.bytes:
                return {'success': True, 'raw_text': b.text, 'bytes': b.bytes.hex(), 'method': 'Direct Read', 'parsed': parse_gs1(b.text)}
                
    # Calculate adaptive kernel sizes based on image size
    min_dim = min(h, w)
    k_sizes = [3, 5, 7, 9, 11]
    if min_dim > 1000:
        k_sizes = [5, 7, 9, 13, 17]
        
    # Preprocessing variations pipeline
    pipelines = []
    
    # A. Morphological Erode (merges dot-matrix dots)
    for k in k_sizes:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
        eroded = cv2.erode(gray, kernel)
        pipelines.append((f'Morph Erode (k={k})', eroded))
        
    # B. Gaussian Blur (smooths dot-matrix dots into continuous blocks)
    for k in k_sizes:
        k_odd = k if k % 2 == 1 else k + 1
        blurred = cv2.GaussianBlur(gray, (k_odd, k_odd), 0)
        pipelines.append((f'Gaussian Blur (k={k_odd})', blurred))
        
    # C. CLAHE + Erode
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8)).apply(gray)
    for k in [3, 5, 7]:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
        eroded_clahe = cv2.erode(clahe, kernel)
        pipelines.append((f'CLAHE + Erode (k={k})', eroded_clahe))

    # Test preprocessing pipelines
    for label, proc_img in pipelines:
        # Try Otsu threshold
        _, thresh = cv2.threshold(proc_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Decode
        barcodes = zxingcpp.read_barcodes(thresh, formats=zxingcpp.BarcodeFormat.DataMatrix, try_rotate=True, try_downscale=True, try_invert=True)
        for b in barcodes:
            if b.text or b.bytes:
                return {
                    'success': True,
                    'raw_text': b.text,
                    'bytes': b.bytes.hex(),
                    'method': f'Pipeline ({label} + Otsu)',
                    'parsed': parse_gs1(b.text)
                }
                
        # Also try raw proc_img without binarization
        barcodes = zxingcpp.read_barcodes(proc_img, formats=zxingcpp.BarcodeFormat.DataMatrix, try_rotate=True, try_downscale=True, try_invert=True)
        for b in barcodes:
            if b.text or b.bytes:
                return {
                    'success': True,
                    'raw_text': b.text,
                    'bytes': b.bytes.hex(),
                    'method': f'Pipeline ({label})',
                    'parsed': parse_gs1(b.text)
                }

    return {'success': False, 'error': 'DataMatrix okunamadı (Tüm ön işleme adımları denendi).'}

if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')

    images = ['test.png']
    if len(sys.argv) > 1:
        images = sys.argv[1:]
        
    print("=" * 60)
    print(" DATAMATRIX OKUYUCU (4 ACI DEMO) ")
    print("=" * 60)
    
    for img_path in images:
        print(f"\n[Goruntu Isleniyor]: {img_path}")
        res = decode_datamatrix(img_path)
        if res['success']:
            print(f"  Status    : BASARILI [OK]")
            print(f"  Yontem    : {res['method']}")
            print(f"  Ham Veri  : {res['raw_text']}")
            print("  GS1 Detaylari:")
            for field, value in res['parsed'].items():
                print(f"    - {field}: {value}")
        else:
            print(f"  Status    : BASARISIZ [FAIL]")
            print(f"  Hata      : {res['error']}")
